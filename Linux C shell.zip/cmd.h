void myexit();
void myclr();
void mypwd();
void myecho();
void mytime();
void myenviron();
void mycd();
void myexec();
void myjobs();
void mydir();

