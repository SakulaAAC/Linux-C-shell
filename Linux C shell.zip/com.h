void readcommand();
int is_internal_cmd();
void printprompt();
int getcommandlen();
void run_external_cmd(int pos);
